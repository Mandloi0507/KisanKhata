// Bilingual labels — English primary, Hindi secondary
export type BiText = { en: string; hi: string };

export const t = (text: BiText) => text; // helper for IDE

export const farmer = {
  id: "KK-MP-2026-00482",
  name: "Ramesh Kumar",
  nameHi: "रमेश कुमार",
  village: "Ganj Basoda",
  district: "Vidisha, Madhya Pradesh",
  districtHi: "विदिशा, मध्य प्रदेश",
  aadhaarMasked: "XXXX-XXXX-4821",
  phone: "+91 98765 43210",
  landAcres: 2.5,
  primaryCrop: "Wheat",
  primaryCropHi: "गेहूँ",
  secondaryCrop: "Soybean",
  secondaryCropHi: "सोयाबीन",
  season: "Rabi 2026",
  seasonHi: "रबी 2026",
  scoreUpdated: "Apr 22, 2026",
};

export const score = {
  value: 742,
  max: 1000,
  band: "Good" as const,
  bandHi: "अच्छा",
  bandToken: "score-good",
  delta: 38,
  lastValue: 704,
};

export const subScores = [
  {
    key: "crop",
    label: "Crop Health (NDVI)",
    labelHi: "फसल स्वास्थ्य",
    value: 168,
    max: 200,
    impact: "+82",
    note: "Wheat NDVI 0.71 — above district avg.",
    noteHi: "गेहूँ की सेहत ज़िले के औसत से बेहतर।",
    source: "NASA POWER · Apr 18, 2026",
  },
  {
    key: "rain",
    label: "Rainfall Risk",
    labelHi: "वर्षा जोखिम",
    value: 142,
    max: 200,
    impact: "+54",
    note: "Seasonal rainfall within normal band.",
    noteHi: "मौसमी वर्षा सामान्य सीमा में।",
    source: "OpenWeatherMap · Apr 21, 2026",
  },
  {
    key: "income",
    label: "Income Potential (Mandi)",
    labelHi: "आय क्षमता",
    value: 156,
    max: 200,
    impact: "+61",
    note: "Wheat ₹2,275/qtl × est. 22 qtl/acre.",
    noteHi: "अनुमानित मौसमी आय ₹1,25,000।",
    source: "AGMARKNET · Apr 20, 2026",
  },
  {
    key: "land",
    label: "Land & Tenure",
    labelHi: "ज़मीन व अधिकार",
    value: 128,
    max: 200,
    impact: "+22",
    note: "2.5 acres, single owner, clear title.",
    noteHi: "2.5 एकड़, स्पष्ट अधिकार।",
    source: "Land Records · 2025",
  },
  {
    key: "scheme",
    label: "Scheme & Insurance",
    labelHi: "योजना व बीमा",
    value: 148,
    max: 200,
    impact: "+38",
    note: "PM-Kisan active, PMFBY enrolled.",
    noteHi: "पीएम-किसान सक्रिय, फसल बीमा।",
    source: "PM-Kisan portal",
  },
];

export const loanOffer = {
  amountMin: 80_000,
  amountMax: 1_50_000,
  rate: 8.5,
  tenureMonths: 12,
  emiEstimate: 13_080,
  bank: "Madhya Bharat Gramin Bank",
  bankHi: "मध्य भारत ग्रामीण बैंक",
  decisionWindow: "24 hours",
};

export const history = [
  { season: "Kharif 2024", value: 612 },
  { season: "Rabi 2024", value: 648 },
  { season: "Kharif 2025", value: 681 },
  { season: "Rabi 2025", value: 704 },
  { season: "Rabi 2026", value: 742 },
];

export const notifications = [
  {
    id: "n1",
    title: "Score updated for Rabi 2026",
    titleHi: "रबी 2026 के लिए स्कोर अपडेट हुआ",
    body: "Your KisanScore went up by 38 points to 742.",
    bodyHi: "आपका किसानस्कोर 38 अंक बढ़कर 742 हो गया।",
    time: "2h ago",
    type: "success" as const,
  },
  {
    id: "n2",
    title: "New loan offer ready",
    titleHi: "नया ऋण प्रस्ताव तैयार",
    body: "Madhya Bharat Gramin Bank pre-approved ₹1.5L @ 8.5%.",
    bodyHi: "बैंक से ₹1.5 लाख का प्रस्ताव।",
    time: "Yesterday",
    type: "info" as const,
  },
  {
    id: "n3",
    title: "Mandi price alert: Wheat",
    titleHi: "मंडी भाव अलर्ट: गेहूँ",
    body: "Wheat at Vidisha mandi up 4% to ₹2,275/qtl.",
    bodyHi: "विदिशा मंडी में गेहूँ का भाव 4% बढ़ा।",
    time: "2 days ago",
    type: "info" as const,
  },
  {
    id: "n4",
    title: "Weather watch: low rainfall",
    titleHi: "मौसम चेतावनी: कम बारिश",
    body: "District rainfall 18% below normal this month.",
    bodyHi: "इस महीने ज़िले में बारिश सामान्य से 18% कम।",
    time: "3 days ago",
    type: "warning" as const,
  },
];

export function formatINR(n: number) {
  return "₹" + n.toLocaleString("en-IN");
}
