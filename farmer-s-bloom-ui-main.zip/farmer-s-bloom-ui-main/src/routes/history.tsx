import { createFileRoute } from "@tanstack/react-router";
import { TrendingUp, ArrowUpRight } from "lucide-react";
import { PhoneShell } from "@/components/PhoneShell";
import { ScreenHeader } from "@/components/ScreenHeader";
import { BottomNav } from "@/components/BottomNav";
import { history } from "@/lib/mock-data";

export const Route = createFileRoute("/history")({
  head: () => ({
    meta: [{ title: "Score history — KisanKhata" }],
  }),
  component: () => (
    <PhoneShell>
      <HistoryPage />
    </PhoneShell>
  ),
});

function HistoryPage() {
  const w = 340;
  const h = 180;
  const pad = 20;
  const max = Math.max(...history.map((h) => h.value)) + 60;
  const min = Math.min(...history.map((h) => h.value)) - 60;
  const xStep = (w - pad * 2) / (history.length - 1);
  const points = history.map((d, i) => ({
    x: pad + i * xStep,
    y: pad + (1 - (d.value - min) / (max - min)) * (h - pad * 2),
  }));
  const path = points.map((p, i) => `${i === 0 ? "M" : "L"} ${p.x} ${p.y}`).join(" ");
  const area = `${path} L ${points[points.length - 1].x} ${h - pad} L ${pad} ${h - pad} Z`;

  const first = history[0].value;
  const last = history[history.length - 1].value;
  const delta = last - first;

  return (
    <div className="min-h-full flex flex-col bg-surface-soft">
      <ScreenHeader title="Score history" titleHi="स्कोर का इतिहास" back="/dashboard" />
      <div className="px-5 space-y-5 pb-4 flex-1">
        {/* Summary card */}
        <div className="rounded-3xl bg-white border border-border p-5 shadow-soft">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-xs text-muted-foreground">Last 5 seasons</div>
              <div className="flex items-baseline gap-2 mt-1">
                <span className="text-4xl font-extrabold tabular-nums text-foreground">
                  {last}
                </span>
                <span className="text-sm text-muted-foreground">/ 1000</span>
              </div>
            </div>
            <span className="flex items-center gap-1 bg-success/10 text-success font-semibold text-sm px-3 py-1.5 rounded-full">
              <TrendingUp className="h-4 w-4" />+{delta}
            </span>
          </div>

          <svg viewBox={`0 0 ${w} ${h}`} className="mt-4 w-full">
            <defs>
              <linearGradient id="grad" x1="0" x2="0" y1="0" y2="1">
                <stop offset="0%" stopColor="var(--color-primary)" stopOpacity="0.35" />
                <stop offset="100%" stopColor="var(--color-primary)" stopOpacity="0" />
              </linearGradient>
            </defs>
            <path d={area} fill="url(#grad)" />
            <path
              d={path}
              fill="none"
              stroke="var(--color-primary)"
              strokeWidth="3"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
            {points.map((p, i) => (
              <g key={i}>
                <circle cx={p.x} cy={p.y} r="6" fill="white" stroke="var(--color-primary)" strokeWidth="3" />
                <text
                  x={p.x}
                  y={p.y - 14}
                  textAnchor="middle"
                  fontSize="10"
                  fontWeight="700"
                  fill="var(--color-foreground)"
                >
                  {history[i].value}
                </text>
              </g>
            ))}
          </svg>

          <div className="flex justify-between text-[10px] text-muted-foreground mt-1 px-2">
            {history.map((d) => (
              <span key={d.season} className="text-center w-12 leading-tight">
                {d.season.replace(" ", "\n")}
              </span>
            ))}
          </div>
        </div>

        {/* Season list */}
        <div className="space-y-2">
          {[...history].reverse().map((h, i) => {
            const prev = history[history.length - i - 2];
            const change = prev ? h.value - prev.value : 0;
            return (
              <div
                key={h.season}
                className="flex items-center justify-between rounded-2xl bg-white border border-border px-4 py-3"
              >
                <div>
                  <div className="font-semibold">{h.season}</div>
                  <div className="text-xs text-muted-foreground">KisanScore</div>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-xl font-extrabold tabular-nums">{h.value}</span>
                  {change !== 0 && (
                    <span
                      className={`text-xs font-semibold px-2 py-0.5 rounded-full flex items-center gap-1 ${
                        change > 0
                          ? "bg-success/10 text-success"
                          : "bg-danger/10 text-danger"
                      }`}
                    >
                      <ArrowUpRight
                        className={`h-3 w-3 ${change < 0 ? "rotate-90" : ""}`}
                      />
                      {change > 0 ? "+" : ""}
                      {change}
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
      <BottomNav />
    </div>
  );
}
