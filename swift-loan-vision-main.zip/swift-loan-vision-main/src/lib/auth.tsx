import { createContext, useContext, useEffect, useState, ReactNode } from "react";
import { Navigate, useLocation } from "react-router-dom";

export interface Banker {
  name: string;
  email: string;
  branch: string;
  initials: string;
}

interface AuthCtx {
  banker: Banker | null;
  signIn: (email: string, password: string) => Promise<void>;
  signUp: (name: string, email: string, password: string, branch: string) => Promise<void>;
  signOut: () => void;
}

const Ctx = createContext<AuthCtx | null>(null);
const STORAGE_KEY = "kk_banker_session";
const USERS_KEY = "kk_banker_users";

interface StoredUser { name: string; email: string; password: string; branch: string; }

function readUsers(): StoredUser[] {
  try { return JSON.parse(localStorage.getItem(USERS_KEY) || "[]"); } catch { return []; }
}
function writeUsers(u: StoredUser[]) { localStorage.setItem(USERS_KEY, JSON.stringify(u)); }

function toBanker(u: StoredUser): Banker {
  const initials = u.name.split(" ").map(s => s[0]).slice(0, 2).join("").toUpperCase() || "B";
  return { name: u.name, email: u.email, branch: u.branch, initials };
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [banker, setBanker] = useState<Banker | null>(() => {
    try { const r = localStorage.getItem(STORAGE_KEY); return r ? JSON.parse(r) : null; } catch { return null; }
  });

  useEffect(() => {
    // Seed a demo banker so users can try the flow without signing up
    const users = readUsers();
    if (!users.find(u => u.email === "priya@kisankhata.in")) {
      users.push({ name: "Priya Nair", email: "priya@kisankhata.in", password: "demo1234", branch: "Nashik Branch" });
      writeUsers(users);
    }
  }, []);

  const persist = (b: Banker | null) => {
    setBanker(b);
    if (b) localStorage.setItem(STORAGE_KEY, JSON.stringify(b));
    else localStorage.removeItem(STORAGE_KEY);
  };

  const signIn: AuthCtx["signIn"] = async (email, password) => {
    const u = readUsers().find(x => x.email.toLowerCase() === email.toLowerCase());
    if (!u) throw new Error("No account found with that email");
    if (u.password !== password) throw new Error("Incorrect password");
    persist(toBanker(u));
  };

  const signUp: AuthCtx["signUp"] = async (name, email, password, branch) => {
    const users = readUsers();
    if (users.find(x => x.email.toLowerCase() === email.toLowerCase())) throw new Error("Email already registered");
    const u: StoredUser = { name, email, password, branch: branch || "Branch" };
    users.push(u);
    writeUsers(users);
    persist(toBanker(u));
  };

  const signOut = () => persist(null);

  return <Ctx.Provider value={{ banker, signIn, signUp, signOut }}>{children}</Ctx.Provider>;
}

export function useAuth() {
  const c = useContext(Ctx);
  if (!c) throw new Error("useAuth must be inside AuthProvider");
  return c;
}

export function RequireAuth({ children }: { children: ReactNode }) {
  const { banker } = useAuth();
  const loc = useLocation();
  if (!banker) return <Navigate to="/auth" replace state={{ from: loc.pathname }} />;
  return <>{children}</>;
}
