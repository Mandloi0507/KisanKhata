import type { Application, PortfolioMetrics, Farmer, ScoreBand } from "./types";
import { bandFor } from "./score";

// API-shaped mocks. Replace each `getX()` with a fetch call later.

const FARMERS: Farmer[] = [
  { id: "KK-2026-00417", name: "Ramesh Kumar", aadhaarMasked: "XXXXXXXX4521", district: "Vidisha", state: "Madhya Pradesh", primaryCrop: "Wheat", secondaryCrop: "Soybean", landAcres: 2.5, phone: "+91 98765 43210" },
  { id: "KK-2026-00418", name: "Sunita Devi", aadhaarMasked: "XXXXXXXX8832", district: "Nashik", state: "Maharashtra", primaryCrop: "Onion", landAcres: 3.2, phone: "+91 98712 33810" },
  { id: "KK-2026-00419", name: "Manjeet Singh", aadhaarMasked: "XXXXXXXX1190", district: "Ludhiana", state: "Punjab", primaryCrop: "Rice", secondaryCrop: "Wheat", landAcres: 5.8, phone: "+91 98700 11233" },
  { id: "KK-2026-00420", name: "Arun Patel", aadhaarMasked: "XXXXXXXX7745", district: "Anand", state: "Gujarat", primaryCrop: "Cotton", landAcres: 4.1, phone: "+91 98010 56712" },
  { id: "KK-2026-00421", name: "Lakshmi Reddy", aadhaarMasked: "XXXXXXXX2298", district: "Guntur", state: "Andhra Pradesh", primaryCrop: "Chilli", landAcres: 1.8, phone: "+91 98221 88410" },
  { id: "KK-2026-00422", name: "Bhairav Joshi", aadhaarMasked: "XXXXXXXX6611", district: "Vidisha", state: "Madhya Pradesh", primaryCrop: "Soybean", landAcres: 3.0, phone: "+91 98456 23910" },
  { id: "KK-2026-00423", name: "Kavita Yadav", aadhaarMasked: "XXXXXXXX0098", district: "Meerut", state: "Uttar Pradesh", primaryCrop: "Sugarcane", landAcres: 2.2, phone: "+91 99012 33344" },
  { id: "KK-2026-00424", name: "Pradeep Kale", aadhaarMasked: "XXXXXXXX5512", district: "Nashik", state: "Maharashtra", primaryCrop: "Grapes", landAcres: 1.5, phone: "+91 98345 12289" },
  { id: "KK-2026-00425", name: "Geeta Bai", aadhaarMasked: "XXXXXXXX3321", district: "Bhilwara", state: "Rajasthan", primaryCrop: "Mustard", landAcres: 2.8, phone: "+91 97654 90011" },
  { id: "KK-2026-00426", name: "Sourav Ghosh", aadhaarMasked: "XXXXXXXX7700", district: "Burdwan", state: "West Bengal", primaryCrop: "Rice", landAcres: 1.2, phone: "+91 98330 12000" },
  { id: "KK-2026-00427", name: "Imran Sheikh", aadhaarMasked: "XXXXXXXX9911", district: "Aurangabad", state: "Maharashtra", primaryCrop: "Cotton", landAcres: 3.6, phone: "+91 98908 77721" },
  { id: "KK-2026-00428", name: "Devika Nair", aadhaarMasked: "XXXXXXXX4488", district: "Palakkad", state: "Kerala", primaryCrop: "Rice", secondaryCrop: "Coconut", landAcres: 2.0, phone: "+91 99221 33344" },
];

const SCORES = [812, 678, 745, 432, 891, 588, 712, 798, 510, 365, 654, 770];
const STATUSES: Application["status"][] = ["Pending","In Review","Approved","Pending","Approved","Pending","In Review","Approved","Rejected","Pending","Pending","In Review"];
const DISTRESS: (Application["distress"])[] = [null,null,null,"Active",null,null,null,null,"Active",null,null,null];
const REQUESTED = [150000, 80000, 120000, 60000, 200000, 90000, 110000, 175000, 50000, 40000, 95000, 130000];

function recommendationFor(score: number) {
  if (score >= 751) return { amountMin: 100000, amountMax: 200000, rate: 7.0, tenureMonths: 12 };
  if (score >= 601) return { amountMin: 60000, amountMax: 120000, rate: 9.5, tenureMonths: 12 };
  if (score >= 401) return { amountMin: 30000, amountMax: 60000, rate: 12.0, tenureMonths: 9 };
  return { amountMin: 0, amountMax: 25000, rate: 14.0, tenureMonths: 6 };
}

function subScoresFor(score: number) {
  const base = score / 1000;
  return [
    { key: "crop_health" as const,    label: "Crop Health (NDVI)", value: Math.round(base * 200 * (0.85 + Math.random()*0.3)), max: 200, trend: "up" as const },
    { key: "rainfall_risk" as const,  label: "Rainfall Risk",      value: Math.round(base * 200 * (0.7 + Math.random()*0.4)),  max: 200, trend: "flat" as const },
    { key: "income_potential" as const, label: "Income Potential",  value: Math.round(base * 200 * (0.9 + Math.random()*0.2)), max: 200, trend: "up" as const },
    { key: "scheme_enrolment" as const, label: "Scheme Enrolment",  value: Math.round(base * 200 * (0.6 + Math.random()*0.5)), max: 200, trend: "up" as const },
  ];
}

function xaiFor(score: number) {
  const positive = score >= 600;
  return [
    { label: "Crop health is above district average for this season", contribution: positive ? 32 : -18, direction: positive ? "positive" as const : "negative" as const, detail: "NDVI 0.71 vs district avg 0.62" },
    { label: "Mandi prices for primary crop trending upward",         contribution: 21, direction: "positive" as const, detail: "Wheat ₹2,340/qtl, +8% MoM" },
    { label: "Rainfall in past 90 days within normal range",          contribution: 14, direction: "positive" as const, detail: "412mm vs 3-yr avg 398mm" },
    { label: "Land area below regional median",                       contribution: -9, direction: "negative" as const, detail: "2.5 acres vs median 3.4" },
    { label: "Active enrolment in PM-KISAN scheme",                   contribution: 12, direction: "positive" as const, detail: "Verified via DBT records" },
    { label: "No prior formal credit history",                        contribution: -7, direction: "negative" as const, detail: "First-time formal applicant" },
  ];
}

const SUMMARIES = [
  "Strong crop health and stable rainfall make this farmer a low-risk candidate. Mandi prices for wheat are trending upward, supporting repayment capacity. Recommend approval at standard rate.",
  "Moderate risk profile. Income potential is solid but limited land area and absence of crop insurance suggest a smaller initial loan with a quarterly review.",
  "Excellent multi-season scoring history with verified scheme enrolment. Eligible for the highest band of recommendation.",
  "Distress conditions detected: drought warning in district combined with a 120-point score drop. Recommend field visit before any decision.",
];

const SEASONS = ["Rabi 2024", "Kharif 2024", "Rabi 2025", "Kharif 2025"];

export const APPLICATIONS: Application[] = FARMERS.map((farmer, i) => {
  const score = SCORES[i];
  const history = SEASONS.map((season, idx) => ({
    season,
    score: Math.max(280, Math.min(950, score - 80 + idx * 28 + Math.round((Math.random()-0.5) * 40))),
  }));
  return {
    id: `APP-${1000 + i}`,
    farmer,
    submittedAt: new Date(Date.now() - i * 36 * 3600 * 1000).toISOString(),
    score,
    band: bandFor(score),
    subScores: subScoresFor(score),
    xai: xaiFor(score),
    summary: SUMMARIES[i % SUMMARIES.length],
    recommendation: recommendationFor(score),
    requestedAmount: REQUESTED[i],
    ledger: i === 8
      ? { status: "duplicate", bankName: "Punjab Gramin Bank", checkedAt: new Date().toISOString() }
      : { status: "clear", checkedAt: new Date().toISOString() },
    distress: DISTRESS[i],
    status: STATUSES[i],
    scoreHistory: history,
  };
});

export const PORTFOLIO: PortfolioMetrics = {
  totalApplications: 248,
  approvalRate: 0.71,
  avgApprovedScore: 742,
  activeDistress: APPLICATIONS.filter(a => a.distress === "Active").length,
  monthlyTrend: [
    { month: "Nov", applications: 28, approvals: 19 },
    { month: "Dec", applications: 34, approvals: 24 },
    { month: "Jan", applications: 41, approvals: 30 },
    { month: "Feb", applications: 38, approvals: 26 },
    { month: "Mar", applications: 52, approvals: 38 },
    { month: "Apr", applications: 55, approvals: 41 },
  ],
  byDistrict: [
    { district: "Vidisha", count: 42 },
    { district: "Nashik", count: 38 },
    { district: "Ludhiana", count: 31 },
    { district: "Anand", count: 27 },
    { district: "Guntur", count: 24 },
    { district: "Meerut", count: 22 },
    { district: "Bhilwara", count: 18 },
  ],
  byBand: [
    { band: "Excellent", count: 64 },
    { band: "Good", count: 98 },
    { band: "Fair", count: 62 },
    { band: "Poor", count: 24 },
  ] as { band: ScoreBand; count: number }[],
};

// API-style accessors (swap implementation later)
export async function getApplications(): Promise<Application[]> { return APPLICATIONS; }
export async function getApplication(id: string): Promise<Application | undefined> {
  return APPLICATIONS.find(a => a.id === id);
}
export async function getPortfolio(): Promise<PortfolioMetrics> { return PORTFOLIO; }
export async function getDistressApplications(): Promise<Application[]> {
  return APPLICATIONS.filter(a => a.distress === "Active");
}
